 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.stripbandunk.jwidget.annotation.TableColumn;
/**
 *
 * @author hp
 */
public class pelanggan {
    
    
 @TableColumn(number=1, name ="NOMOR RENTAL")
 private String no_rental;
 @TableColumn(number=2, name ="NIK")
 private String nik;
 @TableColumn(number=3, name ="NAMA")
 private String nama;
 @TableColumn(number=4, name ="ALAMAT")
 private String alamat; 



   public String getNo_rental() {
        return no_rental;
    }

    public void setNo_rental(String no_rental) {
        this.no_rental = no_rental;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

     public String getNama() {
        return nama;
    }

    public void setNama (String nama) {
        this.nama = nama;
    }


    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

}