/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author hp
 */
public class fasilitas {
    private Connection koneksi;

 public fasilitas() {
 koneksi = koneksidatabase.getKoneksi();
 }
 public void insert(mobil mobil){
 PreparedStatement prepare = null;
 
 try {
     String sql ="INSERT INTO mobil  (no_transaksi,no_polisi,nama,lama_rental,total)VALUES(?,?,?,?,?)";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    prepare.setString(1, mobil.getNo_transaksi());
    prepare.setString(2, mobil.getNo_polisi());
    prepare.setString(3, mobil.getNama());
    prepare.setLong(4, mobil.getLama_rental());
    prepare.setString(5, mobil.getTotal());
    prepare.executeUpdate();
    
     System.out.println("Prepare statement berhasil dibuat");
 }catch(SQLException ex){
    System.out.println("Prepare statement gagal dibuat"); 
    System.out.println("Pesan : " + ex.getMessage());
 }finally{
    if (prepare != null){
 try{
    prepare.close();
     System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
     System.out.println("Prepare statemen gagal ditutup"); 
     System.out.println("Pesan : " + ex.getMessage());

        }
      }
    }
 }
public void update(mobil mobil){
 PreparedStatement prepare = null;
 try {
        String sql ="UPDATE mobil SET no_polisi=?,nama=?,lama_rental=?,total=? WHERE no_transaksi=?";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    prepare.setString(1, mobil.getNo_polisi());
    prepare.setString(2, mobil.getNama());
    prepare.setLong(3, mobil.getLama_rental());
    prepare.setString(4,mobil.getTotal());
    prepare.setString(5,mobil.getNo_transaksi());
    prepare.executeUpdate();
        System.out.println("Prepare statement berhasil dibuat");
 }catch(SQLException ex){
        System.out.println("Prepare statement gagal dibuat"); 
        System.out.println("Pesan : " + ex.getMessage());
 }finally{
 if (prepare != null){
 try{
 prepare.close();
        System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Prepare statemen gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());
         }
       }
    }
 } 
public void delete(String no_transaksi){
 PreparedStatement prepare = null;
 try {
         String sql ="DELETE FROM mobil WHERE no_transaksi=?";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    prepare.setString(1, no_transaksi);
    prepare.executeUpdate();
        System.out.println("Prepare statement berhasil dibuat");
 }catch(SQLException ex){
        System.out.println("Prepare statement gagal dibuat"); 
        System.out.println("Pesan : " + ex.getMessage());
 }finally{
 if (prepare != null){
 try{
    prepare.close();
        System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Prepare statemen gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());

            }
        }
     }
}
public List<mobil> SelectAll(){
    PreparedStatement prepare = null;
    ResultSet result = null;
    List<mobil> list = new ArrayList<>();
 try {
    String sql ="SELECT * FROM mobil";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    result = prepare.executeQuery();
 while (result.next()){
    mobil mobil = new mobil();
    mobil.setNo_transaksi(result.getString("No_transaksi"));
    mobil.setNo_polisi(result.getString("no_polisi"));
    mobil.setNama(result.getString("nama"));
    mobil.setLama_rental(result.getLong("lama_rental"));
    mobil.setTotal(result.getString("total"));
    list.add(mobil);
 }
        System.out.println("Prepare statement berhasil dibuat");
 return list;
 }catch(SQLException ex){
        System.out.println("Prepare statement gagal dibuat"); 
        System.out.println("Pesan : " + ex.getMessage());
 return list;
 }finally{
 if (prepare != null){
 try{
     prepare.close();
        System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Prepare statemen gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());
 }
 }
 if (result != null){

try{
    result.close();
        System.out.println("Resultset berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Resultset gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());
                }
            }
        }
    }

}