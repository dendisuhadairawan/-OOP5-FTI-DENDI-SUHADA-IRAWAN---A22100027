/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.stripbandunk.jwidget.annotation.TableColumn;
/**
 *
 * @author hp
 */
public class mobil {
    
    
 @TableColumn(number=1, name ="NOMOR TRANSAKSI")
 private String no_transaksi;
 @TableColumn(number=2, name ="NO POLISI")
 private String no_polisi;
 @TableColumn(number=3, name ="NAMA")
 private String nama;
 @TableColumn(number=4, name ="LAMA RENTAL")
 private Long lama_rental; 
@TableColumn(number=5, name ="TOTAL")
 private String total; 


   public String getNo_transaksi() {
        return no_transaksi;
    }

    public void setNo_transaksi(String no_transaksi) {
        this.no_transaksi = no_transaksi;
    }

    public String getNo_polisi() {
        return no_polisi;
    }

    public void setNo_polisi(String no_polisi) {
        this.no_polisi = no_polisi;
    }

     public String getNama() {
        return nama;
    }

    public void setNama (String nama) {
        this.nama = nama;
    }
    
    public long getLama_rental() {
        return lama_rental;
    }

    public void setLama_rental(long lama_rental) {
        this.lama_rental = lama_rental;
    }


public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

}
