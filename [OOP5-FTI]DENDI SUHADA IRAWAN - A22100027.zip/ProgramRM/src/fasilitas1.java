/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author hp
 */
public class fasilitas1 {
    private Connection koneksi; 
 public fasilitas1() {
 koneksi = koneksidatabase.getKoneksi();
 }
 public void insert(pelanggan pelanggan){
 PreparedStatement prepare = null;
 
 try {
     String sql ="INSERT INTO pelanggan  (no_rental,nik,nama,alamat)VALUES(?,?,?,?)";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    prepare.setString(1,pelanggan.getNo_rental());
    prepare.setString(2,pelanggan.getNik());
    prepare.setString(3,pelanggan.getNama());
    prepare.setString(4, pelanggan.getAlamat());
    prepare.executeUpdate();
    
     System.out.println("Prepare statement berhasil dibuat");
 }catch(SQLException ex){
    System.out.println("Prepare statement gagal dibuat"); 
    System.out.println("Pesan : " + ex.getMessage());
 }finally{
    if (prepare != null){
 try{
    prepare.close();
     System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
     System.out.println("Prepare statemen gagal ditutup"); 
     System.out.println("Pesan : " + ex.getMessage());

        }
      }
    }
 }
public void update(pelanggan pelanggan){
 PreparedStatement prepare = null;
 try {
        String sql ="UPDATE pelanggan SET nik=?,nama=?,alamat=? WHERE no_rental=?";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    prepare.setString(1, pelanggan.getNik());
    prepare.setString(2, pelanggan.getNama());
    prepare.setString(3, pelanggan.getAlamat());
    prepare.setString(4,   pelanggan.getNo_rental());
    prepare.executeUpdate();
        System.out.println("Prepare statement berhasil dibuat");
 }catch(SQLException ex){
        System.out.println("Prepare statement gagal dibuat"); 
        System.out.println("Pesan : " + ex.getMessage());
 }finally{
 if (prepare != null){
 try{
 prepare.close();
        System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Prepare statemen gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());
         }
       }
    }
 } 
public void delete(String no_rental){
 PreparedStatement prepare = null;
 try {
         String sql ="DELETE FROM pelanggan WHERE no_rental=?";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    prepare.setString(1, no_rental);
    prepare.executeUpdate();
        System.out.println("Prepare statement berhasil dibuat");
 }catch(SQLException ex){
        System.out.println("Prepare statement gagal dibuat"); 
        System.out.println("Pesan : " + ex.getMessage());
 }finally{
 if (prepare != null){
 try{
    prepare.close();
        System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Prepare statemen gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());

            }
        }
     }
}
public List<pelanggan> SelectAll(){
    PreparedStatement prepare = null;
    ResultSet result = null;
    List<pelanggan> list = new ArrayList<>();
 try {
    String sql ="SELECT * FROM pelanggan";
    prepare = (PreparedStatement) koneksi.prepareStatement(sql);
    result = prepare.executeQuery();
 while (result.next()){
    pelanggan pelanggan = new pelanggan();
    pelanggan.setNo_rental(result.getString("No_rental"));
    pelanggan.setNik(result.getString("nik"));
    pelanggan.setNama(result.getString("nama"));
    pelanggan.setAlamat(result.getString("Alamat"));
    list.add(pelanggan);
 }
        System.out.println("Prepare statement berhasil dibuat");
 return list;
 }catch(SQLException ex){
        System.out.println("Prepare statement gagal dibuat"); 
        System.out.println("Pesan : " + ex.getMessage());
 return list;
 }finally{
 if (prepare != null){
 try{
     prepare.close();
        System.out.println("Prepare statemen berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Prepare statemen gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());
 }
 }
 if (result != null){

try{
    result.close();
        System.out.println("Resultset berhasil ditutup");
 }catch(SQLException ex){
        System.out.println("Resultset gagal ditutup"); 
        System.out.println("Pesan : " + ex.getMessage());
                }
            }
        }
    }
}
